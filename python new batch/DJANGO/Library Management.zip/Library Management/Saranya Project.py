class Book:
    def __init__(self, title, author, isbn):
        self.title, self.author, self.isbn, self.available = title, author, isbn, True


class Library:
    def __init__(self):
        self.books = []

    def add_book(self, book):
        self.books.append(book)
        print("Book added!")

    def remove_book(self, isbn):
        self.books[:] = [b for b in self.books if b.isbn != isbn] or print("Book not found!")

    def search_book(self, keyword):
        [print(f"{b.title} by {b.author} (ISBN: {b.isbn}) - {'Available' if b.available else 'Checked Out'}") 
         for b in self.books if keyword.lower() in b.title.lower() or keyword.lower() in b.author.lower()] or print("No matches!")

    def display_books(self):
        [print(f"{b.title} by {b.author} (ISBN: {b.isbn}) - {'Available' if b.available else 'Checked Out'}") 
         for b in self.books] or print("Empty library!")

    def check_out_book(self, isbn):
        any(b.isbn == isbn and (setattr(b, 'available', False) or print("Checked out!")) 
        for b in self.books) or print("Book not found!")

    def return_book(self, isbn):
        any(b.isbn == isbn and (setattr(b, 'available', True) or print("Returned!")) 
        for b in self.books) or print("Book not found!")


# Main program
library = Library()
while True:
    print("\n1. Add Book\n2. Remove Book\n3. Search Book\n4. Display Books\n5. Check Out\n6. Return Book\n7. Exit")
    if (choice := input("Choice (1-7): ")) == '1':
        library.add_book(Book(input("Title: "), input("Author: "), input("ISBN: ")))
    elif choice == '2':
        library.remove_book(input("ISBN to remove: "))
    elif choice == '3':
        library.search_book(input("Search term: "))
    elif choice == '4':
        library.display_books()
    elif choice == '5':
        library.check_out_book(input("ISBN to checkout: "))
    elif choice == '6':
        library.return_book(input("ISBN to return: "))
    elif choice == '7':
        exit()
    else:
        print("Invalid choice!")